# auth/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from django.contrib.auth import authenticate
from django.utils.translation import gettext_lazy as _

from .serializers import UserSerializer
from rest_framework_simplejwt.tokens import RefreshToken

class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        """
        Регистрация нового пользователя.

        Параметры:
        - username (str)
        - email (str)
        - password (str)
        - first_name (str)
        - last_name (str)
        - employee (dict):
            - role (str)
            - phone (str)
            - photo (file)

        Возвращает:
        - access/refresh JWT токены
        - данные пользователя
        """
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    


class ProfileUpdateView(APIView):
    permission_classes = [permissions.IsAuthenticated]
   

    def put(self, request):
        """
        Обновление профиля пользователя

        PUT /api/users/profile/

        Request Body:
            {
                "username": "string",
                "email": "string",
                "first_name": "string",
                "last_name": "string",
                "employee": {
                    "role": "string",
                    "phone": "string",
                    "photo": "string"
                }
            }

        Response:
            200: {
                "id": integer,
                "username": "string",
                "email": "string",
                "first_name": "string",
                "last_name": "string",
                "employee": {
                    "role": "string",
                    "phone": "string",
                    "photo": "string"
                }
            }
            400: {
                "error": "string"
            }
        """
        user = request.user
        serializer = UserSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)